# React-Todo-App
Todo list app project using react hooks
Here is the screenshot of the project.

<img width="457" alt="image" src="https://user-images.githubusercontent.com/36126362/213862825-c5c342c6-6ba1-421a-9784-2848368feea4.png">

<h3>Functionalities:</h3>
<ol>
  <li> Add Todo by clicking add button</li>
  <li> Add Todo by pressing Enter key</li>
  <li> Delete Todo</li>
 </ol>
 <h1> Video tutorial for the same in Hindi</h1>
 <a href="https://youtu.be/RxPF47orKzo"> Video Tutorial</a>
